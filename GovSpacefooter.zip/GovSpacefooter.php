<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GovSpace Footer</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="footer.css">
</head>
<body>

  <footer>
    <img src="GovSpace Solo Logo.png" alt="GovSpace Background" class="footer-bg-logo">

    <div class="footer-top">
      <div class="footer-logo">
        <img src="GovSpace_Inverted_2-BGRemove.png" alt="GovSpace Logo">
      </div>
      <div class="footer-links">
        <a href="#">Privacy Policy</a>
        <a href="#">Terms of Use</a>
        <a href="#">About</a>
      </div>
    </div>

    <div class="footer-bottom">
      <span>© 2025 GovSpace. All Rights Reserved</span>
      <div class="social-icons">
        <a href="#"><i class="fab fa-facebook-f"></i></a>
        <a href="#"><i class="fab fa-instagram"></i></a>
        <a href="#"><i class="fab fa-x-twitter"></i></a>
        <a href="#"><i class="fab fa-youtube"></i></a>
      </div>
    </div>
  </footer>

</body>
</html>
