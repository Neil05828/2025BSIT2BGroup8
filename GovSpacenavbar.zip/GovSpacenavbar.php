<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GovSpace Navigation Bar</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header class="navbar">
    <div class="logo">
      <img src="GovSpace Inverted 2.png" alt="GovSpace Logo">
    </div>
    <div class="nav-icons">
      <a href="#" class="nav-item">
        <i class="fa-solid fa-house"></i>
        <span>Home</span>
      </a>
      <a href="#" class="nav-item">
        <i class="fa-solid fa-briefcase"></i>
        <span>Jobs</span>
      </a>
      <a href="#" class="nav-item">
        <i class="fa-solid fa-comment-dots"></i>
        <span>Messages</span>
      </a>
      <a href="#" class="nav-item">
        <i class="fa-solid fa-bell"></i>
        <span>Notifications</span>
      </a>
    </div>
  </header>
</body>
</html>
