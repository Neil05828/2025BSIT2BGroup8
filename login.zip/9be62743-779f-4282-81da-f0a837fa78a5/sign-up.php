<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>GovSpace - Sign Up</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>

  <div class="form-container">
    <div class="form-box">
      <h2>Let’s Create your Account</h2>

      <input type="text" placeholder="First Name">
      <input type="text" placeholder="Middle Name">
      <input type="text" placeholder="Last Name">

      <input type="password" placeholder="Password">
      <input type="password" placeholder="Re-type Password">

      <div class="phone-row">
        <select>
          <option value="+63">🇵🇭 +63</option>
          <option value="+1">🇺🇸 +1</option>
          <option value="+44">🇬🇧 +44</option>
        </select>
        <input type="text" placeholder="Contact Number">
      </div>

      <input type="date" placeholder="Date of Birth">
      <input type="text" placeholder="Enter email or phone number">

      <p>By clicking continue, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></p>

      <button>Sign Up</button>
    </div>
  </div>

</body>
</html>
