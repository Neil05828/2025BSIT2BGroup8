<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>GovSpace — Sign In</title>

  <!-- External CSS -->
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <main class="wrap" role="main">
    <div class="card" role="region" aria-labelledby="signin-heading">
      <section class="left">
        <div class="brand" id="signin-heading">
          <span class="dark">GOV</span><span class="accent">SPACE</span>
        </div>

        <form id="loginForm" aria-describedby="login-desc" novalidate>
          <p id="login-desc" class="muted">Sign in to your GovSpace account to access municipal services.</p>

          <div style="margin-top:18px;">
            <label for="email">Email</label>
            <input id="email" name="email" type="email" inputmode="email" placeholder="you@example.gov" required aria-required="true" />
          </div>

          <div style="margin-top:14px;">
            <label for="password">Password</label>
            <input id="password" name="password" type="password" placeholder="••••••••" required aria-required="true" />
          </div>

          <div class="actions">
            <button type="submit" class="btn btn-sign" id="signBtn">Sign In</button>
            <a class="link" href="#" id="forgot">Forgot password?</a>
          </div>

          <div class="create">
            Create an Account? <a href="#" class="link">Sign-up</a>
          </div>

          <div class="social-row" aria-hidden="false">
            <div class="social" role="group" aria-label="social sign in">
              <a href="#" title="Continue with Facebook" aria-label="Continue with Facebook" id="fb">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="12" cy="12" r="11" stroke="currentColor" stroke-opacity="0.12"/>
                  <path d="M14 8h1.5V6.3A3.5 3.5 0 0 0 12.3 3H11v3H9v2h2v6h2v-6h1.8L14 8z" fill="currentColor"/>
                </svg>
              </a>

              <a href="#" title="Continue with Google" aria-label="Continue with Google" id="gg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="12" cy="12" r="11" stroke="currentColor" stroke-opacity="0.12"/>
                  <path d="M12 7v3.4h4.4C16.7 6.8 14.6 7 12 7zM7.8 9.7C7.5 10.6 7.3 11.9 7.3 12.9c0 1 .2 2.4.5 3.3L9.9 15C9.7 14 9.7 12.9 9.7 12.9s0-1.1.2-2.1L7.8 9.7zM12 17c1.8 0 3.3-.6 4.4-1.6l-2.1-1.6c-.6.4-1.5.6-2.3.6-1.9 0-3.6-1.3-4.2-3.1L6 12c.5 2.3 2.6 5 6 5z" fill="currentColor"/>
                </svg>
              </a>

              <a href="#" title="Continue with X / Twitter" aria-label="Continue with X" id="x">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="12" cy="12" r="11" stroke="currentColor" stroke-opacity="0.12"/>
                  <path d="M7 8c2.7 2.2 5 3 9 3-0.3 2.3-2.1 5.9-7 6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </a>
            </div>
          </div>
        </form>
      </section>

      <aside class="right" aria-hidden="false">
        <img src="https://upload.wikimedia.org/wikipedia/en/thumb/0/0c/Bacolod_New_Government_Center_2023-08-06.jpg/1600px-Bacolod_New_Government_Center_2023-08-06.jpg?20230807082435" 
             alt="City hall building, reflective pool, clear sky" class="hero" />
      </aside>
    </div>
  </main>

  <script>
    (function(){
      const form = document.getElementById('loginForm');
      const email = document.getElementById('email');
      const password = document.getElementById('password');

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!email.value || !password.value) {
          alert('Please enter both email and password.');
          return;
        }
        document.getElementById('signBtn').textContent = 'Signing...';
        setTimeout(() => {
          document.getElementById('signBtn').textContent = 'Sign In';
          alert('This is a demo. Wire up your auth backend to proceed.');
        }, 900);
      });

      document.body.addEventListener('keydown', e => {
        if (e.key === 'Tab') document.documentElement.style.scrollBehavior = 'smooth';
      });
    })();
  </script>
</body>
</html>
